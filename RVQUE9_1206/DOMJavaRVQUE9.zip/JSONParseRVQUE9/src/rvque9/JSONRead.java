package rvque9;


import org.json.JSONObject;
import org.json.XML;
import org.json.JSONArray;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;

public class JSONRead {
    public static void main(String[] args) {
        String xmlFilePath = "orarendRVQUE9.xml";
        String jsonFilePath = "orarendRVQUE9.json";

        try {
            // Read the XML file content as a String
            String xmlContent = new String(Files.readAllBytes(Paths.get(xmlFilePath)));

            // Convert the XML content to JSON
            JSONObject jsonObject = XML.toJSONObject(xmlContent);

            // Write the JSON content to a file
            Files.write(Paths.get(jsonFilePath), jsonObject.toString(4).getBytes());

            // Read the JSON file content as a String
            String jsonContent = new String(Files.readAllBytes(Paths.get(jsonFilePath)));

            // Parse the JSON content
            JSONObject parsedJsonObject = new JSONObject(jsonContent);

            // Display the JSON content in a structured format
            displayJsonObject(parsedJsonObject, "");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void displayJsonObject(JSONObject jsonObject, String indent) {
        for (String key : jsonObject.keySet()) {
            Object value = jsonObject.get(key);
            if (value instanceof JSONObject) {
                System.out.println(indent + key + ":");
                displayJsonObject((JSONObject) value, indent + "  ");
            } else if (value instanceof JSONArray) {
                System.out.println(indent + key + ":");
                displayJsonArray((JSONArray) value, indent + "  ");
            } else {
                System.out.println(indent + key + ": " + value);
            }
        }
    }

    private static void displayJsonArray(JSONArray jsonArray, String indent) {
        for (int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            if (value instanceof JSONObject) {
                displayJsonObject((JSONObject) value, indent);
            } else if (value instanceof JSONArray) {
                displayJsonArray((JSONArray) value, indent);
            } else {
                System.out.println(indent + "- " + value);
            }
        }
    }
}
