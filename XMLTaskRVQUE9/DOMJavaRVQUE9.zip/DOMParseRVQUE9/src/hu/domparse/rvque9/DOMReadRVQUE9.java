package hu.domparse.rvque9;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import java.io.File;

public class DOMReadRVQUE9 {
    public static void main(String[] args) {
        try {
            // Create a DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Create a DocumentBuilder
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Parse the XML file and build the Document
            Document document = builder.parse(new File("XMLRVQUE9.xml"));
            // Normalize the XML structure
            document.getDocumentElement().normalize();
            // Print the root element
            System.out.println("Root element: " + document.getDocumentElement().getNodeName());
            // Get all Taxi elements
            NodeList nodeList = document.getElementsByTagName("Taxi");
            // Iterate through the nodes and print the details
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    System.out.println("TaxiID: " + element.getElementsByTagName("TaxiID").item(0).getTextContent());
                    System.out.println("Rendszam: " + element.getElementsByTagName("Rendszam").item(0).getTextContent());
                    System.out.println("Model: " + element.getElementsByTagName("Model").item(0).getTextContent());
                    System.out.println("Kapacitas: " + element.getElementsByTagName("Kapacitas").item(0).getTextContent());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


