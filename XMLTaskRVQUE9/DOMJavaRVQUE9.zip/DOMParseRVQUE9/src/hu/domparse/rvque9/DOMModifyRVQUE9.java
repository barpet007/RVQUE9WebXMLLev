package hu.domparse.rvque9;

import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;

public class DOMModifyRVQUE9 {
    public static void main(String[] args) {
        try {
            // Create a DocumentBuilderFactory
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Create a DocumentBuilder
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Parse the XML file and build the Document
            Document document = builder.parse(new File("XMLRVQUE9.xml"));
            // Normalize the XML structure
            document.getDocumentElement().normalize();
            // Modify specific data
            NodeList nodeList = document.getElementsByTagName("Taxi");
            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;
                    String taxiID = element.getElementsByTagName("TaxiID").item(0).getTextContent();
                    if (taxiID.equals("03")) {
                        element.getElementsByTagName("Model").item(0).setTextContent("AUDI A6");
                    }
                }
            }
            // Write the modified document to a new file
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(document);
            StreamResult result = new StreamResult(new File("XMLRVQUE9_modified.xml"));
            transformer.transform(source, result);
            System.out.println("XML file updated successfully");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
